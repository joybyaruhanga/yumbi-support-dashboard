/*
 * fetch-stats.js
 * Runs on a GitHub Actions runner (Node 20, global fetch available).
 * Reads API tokens from environment secrets, pulls AGGREGATE support
 * metrics from each channel for a set of date ranges, and writes data.json.
 *
 * IMPORTANT — HONESTY NOTE:
 *   The framework below (secrets, ranges, aggregation, output shape,
 *   error handling) is complete and correct. The three per-provider
 *   functions contain the auth pattern and request skeleton, but the
 *   EXACT endpoint paths and response field names must be filled in
 *   from each provider's own API docs (linked inline). Until a provider
 *   is wired, its values come back null and a note lands in errors[],
 *   which the dashboard shows plainly. Nothing here is faked as "real".
 *
 * Output contract (consumed by index.html):
 *   { generated_at, as_of, ranges: { today, yesterday, last7, last30, month } }
 *   each range: { from, to, euphoria{...}, chat{...}, zoho{...}, errors[] }
 */

const fs = require("fs");

/* ---------- date ranges (UTC) ---------- */
function ymd(d){ return d.toISOString().slice(0,10); }
function buildRanges(){
  const today = new Date(); today.setUTCHours(0,0,0,0);
  const shift = n => { const x=new Date(today); x.setUTCDate(x.getUTCDate()+n); return x; };
  const monthStart = new Date(Date.UTC(today.getUTCFullYear(), today.getUTCMonth(), 1));
  return {
    today:     { from: ymd(today),     to: ymd(today) },
    yesterday: { from: ymd(shift(-1)), to: ymd(shift(-1)) },
    last7:     { from: ymd(shift(-6)), to: ymd(today) },
    last30:    { from: ymd(shift(-29)),to: ymd(today) },
    month:     { from: ymd(monthStart),to: ymd(today) }
  };
}

/* ---------- helpers ---------- */
const need = (name) => {
  const v = process.env[name];
  if (!v) throw new Error(`${name} secret is not set`);
  return v;
};

/* =========================================================
 * EUPHORIA  (voice)  — https://support.euphoria.co.za/support/solutions/109665
 * Auth: your Euphoria API token (stored as the EUPHORIA_API_TOKEN secret).
 * Fill in the real endpoint + response mapping for call stats.
 * ========================================================= */
async function euphoria(range){
  const base  = need("EUPHORIA_API_BASE");   // e.g. https://api.euphoria.co.za/...
  const token = need("EUPHORIA_API_TOKEN");

  // >>> TODO: replace with Euphoria's real call-stats endpoint + query params.
  // Example shape only — DO NOT assume these paths are correct:
  //   const res = await fetch(`${base}/calls/summary?from=${range.from}&to=${range.to}`, {
  //     headers: { "Authorization": `Bearer ${token}` }
  //   });
  //   const j = await res.json();
  //   return { received:j.total, answered:j.answered, abandoned:j.abandoned, agents:j.agents_online };
  throw new Error("Euphoria endpoint not wired yet (see scripts/fetch-stats.js).");
}

/* =========================================================
 * ZOHO DESK (tickets) — https://desk.zoho.com/DeskAPIDocument
 * Auth: OAuth 2.0. The refresh-token exchange below is complete;
 * the ticket queries need the real endpoints/field names.
 * ========================================================= */
async function zohoAccessToken(){
  const dc = process.env.ZOHO_DC || "com";
  const params = new URLSearchParams({
    refresh_token: need("ZOHO_REFRESH_TOKEN"),
    client_id:     need("ZOHO_CLIENT_ID"),
    client_secret: need("ZOHO_CLIENT_SECRET"),
    grant_type:    "refresh_token"
  });
  const res = await fetch(`https://accounts.zoho.${dc}/oauth/v2/token`, { method:"POST", body: params });
  const j = await res.json();
  if (!j.access_token) throw new Error("Zoho token exchange failed: " + JSON.stringify(j));
  return j.access_token;
}
async function zoho(range){
  const dc = process.env.ZOHO_DC || "com";
  const org = need("ZOHO_ORG_ID");
  const access = await zohoAccessToken();
  const headers = { "Authorization": `Zoho-oauthtoken ${access}`, "orgId": org };
  const apiBase = `https://desk.zoho.${dc}/api/v1`;

  // >>> TODO: replace with the real Desk queries + field mapping.
  // Snapshot counts use ticket views/criteria; handled/response/resolution
  // use report or metrics endpoints filtered by range.from/range.to.
  //   const open = await (await fetch(`${apiBase}/ticketsCount?status=Open`, {headers})).json();
  void headers; void apiBase;
  throw new Error("Zoho Desk queries not wired yet (see scripts/fetch-stats.js).");
}

/* =========================================================
 * INTERCOM (live chat) — https://developers.intercom.com
 * Auth: Bearer access token (INTERCOM_TOKEN). Base: https://api.intercom.io
 * Use the conversations search API filtered by created_at for volumes,
 * and conversation ratings for CSAT. Fill in query + mapping.
 * ========================================================= */
async function intercom(range){
  const token = need("INTERCOM_TOKEN");
  const headers = { "Authorization": `Bearer ${token}`, "Content-Type":"application/json", "Accept":"application/json" };

  // >>> TODO: replace with the real conversations.search query + mapping.
  //   const res = await fetch("https://api.intercom.io/conversations/search", {
  //     method:"POST", headers, body: JSON.stringify({ query: { ... created_at between from/to ... } })
  //   });
  void headers;
  throw new Error("Intercom queries not wired yet (see scripts/fetch-stats.js).");
}

/* ---------- run one provider safely into the range result ---------- */
async function safe(label, fn, range, errors){
  try { return await fn(range); }
  catch (e) { errors.push(`${label}: ${e.message}`); return null; }
}

async function buildRange(name, span){
  const errors = [];
  const e = await safe("Euphoria", euphoria, span, errors);
  const c = await safe("Live Chat", intercom, span, errors);
  const z = await safe("Zoho", zoho, span, errors);
  return {
    from: span.from, to: span.to,
    euphoria: e || { received:null, answered:null, abandoned:null, agents:null },
    chat:     c || { received:null, handled:null, csat:null },
    zoho:     z || { unassigned:null, open:null, config:null, thirdparty:null, handled_total:null, avg_first_response:null, avg_resolution:null },
    errors
  };
}

(async function main(){
  const spans = buildRanges();
  const ranges = {};
  for (const key of Object.keys(spans)) {
    ranges[key] = await buildRange(key, spans[key]);
  }
  const out = { generated_at: new Date().toISOString(), as_of: new Date().toISOString(), ranges };
  fs.writeFileSync("data.json", JSON.stringify(out, null, 2));
  console.log("Wrote data.json");
})().catch(err => { console.error(err); process.exit(1); });
